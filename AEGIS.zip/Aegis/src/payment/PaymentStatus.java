package payment;

public enum PaymentStatus {
    PAID, PENDING, EXPIRES;
}
