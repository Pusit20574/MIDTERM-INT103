package account;

public enum Position {
    DEPARTMENT, STUDENT
}
