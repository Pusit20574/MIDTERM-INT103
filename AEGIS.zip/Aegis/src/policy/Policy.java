package policy;

public interface Policy {

    public static final int MAX_COURSES = 7;
    public static final int MIN_COURSES = 3;

}
